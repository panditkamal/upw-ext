// ai_analyzer.js - Upwork Job Intelligence, Client Risk Scoring & AI Proposal Engine

/**
 * Evaluates Client Safety & Hire Trust Score (0 - 100)
 */
function analyzeClientTrust(jobData) {
  let score = 70; // baseline
  const redFlags = [];
  const greenFlags = [];

  const text = `${jobData.client} ${jobData.title} ${jobData.rawDetails || ''}`.toLowerCase();

  // 1. Suspension Check (Critical Red Flag - as seen in user screenshot)
  if (text.includes('suspended') || text.includes('client is suspended')) {
    score -= 75;
    redFlags.push('🚨 CRITICAL: Client account is suspended! Do not waste connects.');
  }

  // 2. Rating Check
  const ratingMatch = jobData.client.match(/(\d+\.\d+)★/);
  if (ratingMatch) {
    const rating = parseFloat(ratingMatch[1]);
    if (rating < 3.0) {
      score -= 35;
      redFlags.push(`⚠️ Very Low Rating (${rating}★): High risk of disputes or difficult client.`);
    } else if (rating < 4.2) {
      score -= 15;
      redFlags.push(`⚠️ Mediocre Rating (${rating}★): Check past freelancer feedback.`);
    } else if (rating >= 4.8) {
      score += 15;
      greenFlags.push(`⭐ Excellent Feedback (${rating}★): Reliable and professional employer.`);
    }
  }

  // 3. Payment Verification
  if (/payment verified/i.test(jobData.client)) {
    score += 15;
    greenFlags.push('💳 Payment Method Verified.');
  } else if (/unverified/i.test(jobData.client)) {
    score -= 20;
    redFlags.push('⚠️ Payment Unverified: Client has not added a verified credit card yet.');
  }

  // 4. Spend Level
  const spentMatch = jobData.client.match(/\$([\d,]+)[kKmM]?\s*spent/i);
  if (spentMatch) {
    greenFlags.push(`💰 Client has spent ${spentMatch[0]} on Upwork.`);
    score += 10;
  } else if (/0 spent|\$0/i.test(jobData.client)) {
    score -= 10;
    redFlags.push('🆕 Brand New Client ($0 spent): May take longer to make their first hire.');
  }

  // Normalize score between 5 and 100
  const finalScore = Math.max(5, Math.min(100, score));

  let trustVerdict = 'SAFE CLIENT';
  let badgeColor = '#15803d'; // green
  if (finalScore < 40) {
    trustVerdict = 'HIGH RISK / DO NOT APPLY';
    badgeColor = '#ef4444'; // red
  } else if (finalScore < 65) {
    trustVerdict = 'PROCEED WITH CAUTION';
    badgeColor = '#f59e0b'; // amber
  }

  return {
    score: finalScore,
    verdict: trustVerdict,
    badgeColor,
    redFlags,
    greenFlags
  };
}

/**
 * Generates an Elite Copy-Paste Master AI Prompt for ChatGPT / Claude / Gemini
 */
function generateWinningProposalPrompt(jobData, userSkills) {
  const skillsStr = userSkills && userSkills.length > 0 ? userSkills.join(', ') : 'Web & Mobile Development, QA Testing';

  return `Act as an elite, top-rated Upwork freelancer who wins 80%+ of submitted proposals. 
Write a personalized, high-converting proposal for the Upwork job below.

[JOB DETAILS]
• Title: ${jobData.title}
• Budget: ${jobData.budget || 'Competitive'}
• Client Info: ${jobData.client || 'Verified'}
• Job Scope & Requirements:
${jobData.description || jobData.title}

[MY SKILLS & PROFILE]
• Core Competencies: ${skillsStr}

[PROPOSAL WINNING RULES - STRICTLY FOLLOW]
1. FIRST 2 LINES (THE HOOK): Must address their exact technical problem immediately. Do NOT use generic openings like "Dear Hiring Manager", "I read your job post", or "I am excited to apply".
2. DELIVERABLE BREAKDOWN: Briefly explain your step-by-step approach to solve their exact deliverables.
3. PROOF / RELEVANCE: Mention 1 highly relevant past project experience without writing long walls of text.
4. SMART QUALIFYING QUESTIONS: Include 2 sharp, insightful questions about their project that prove you are an expert who thought through their scope.
5. LENGTH & TONE: Keep it under 180 words. Modern, confident, professional, and mobile-friendly.
6. CALL TO ACTION: A casual, low-pressure invite to chat (e.g. "Are you free for a quick 5-min chat today to discuss your testing checklist?").

Write the proposal now:`;
}

if (typeof module !== 'undefined') {
  module.exports = { analyzeClientTrust, generateWinningProposalPrompt };
}
